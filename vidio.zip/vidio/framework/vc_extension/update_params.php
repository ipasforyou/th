<?php
/**
 * @package    HaruTheme
 * @version    1.0.0
 * @author     Administrator <admin@harutheme.com>
 * @copyright  Copyright (c) 2017, HaruTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://harutheme.com
 ** 
 * Add param to exits shortcode
 * 1. vc_row
 * 2. vc_row_inner
 * 3. vc_column
 */

function haru_add_vc_param() {
    if (function_exists('vc_add_param')) {
        $add_css_animation = array(
            'type'        => 'dropdown',
            'heading'     => esc_html__( 'CSS Animation', 'vidio' ),
            'param_name'  => 'css_animation',
            'value'       => array(
                esc_html__( 'No', 'vidio' )                   => '', 
                esc_html__( 'Fade In', 'vidio')               => 'wpb_fadeIn', 
                esc_html__( 'Fade Top to Bottom', 'vidio' )   => 'wpb_fadeInDown', 
                esc_html__( 'Fade Bottom to Top', 'vidio' )   => 'wpb_fadeInUp', 
                esc_html__( 'Fade Left to Right', 'vidio' )   => 'wpb_fadeInLeft', 
                esc_html__( 'Fade Right to Left', 'vidio' )   => 'wpb_fadeInRight', 
                esc_html__( 'Bounce In', 'vidio')             => 'wpb_bounceIn', 
                esc_html__( 'Bounce Top to Bottom', 'vidio' ) => 'wpb_bounceInDown', 
                esc_html__( 'Bounce Bottom to Top', 'vidio' ) => 'wpb_bounceInUp', 
                esc_html__( 'Bounce Left to Right', 'vidio' ) => 'wpb_bounceInLeft', 
                esc_html__( 'Bounce Right to Left', 'vidio' ) => 'wpb_bounceInRight', 
                esc_html__( 'Zoom In', 'vidio' )              => 'wpb_zoomIn', 
                esc_html__( 'Flip Vertical', 'vidio' )        => 'wpb_flipInX', 
                esc_html__( 'Flip Horizontal', 'vidio' )      => 'wpb_flipInY', 
                esc_html__( 'Bounce', 'vidio' )               => 'wpb_bounce', 
                esc_html__( 'Flash', 'vidio' )                => 'wpb_flash', 
                esc_html__( 'Shake', 'vidio' )                => 'wpb_shake', 
                esc_html__('Pulse', 'vidio' )                 => 'wpb_pulse', 
                esc_html__( 'Swing', 'vidio')                 => 'wpb_swing', 
                esc_html__( 'Rubber band', 'vidio' )          => 'wpb_rubberBand', 
                esc_html__( 'Wobble', 'vidio' )               => 'wpb_wobble', 
                esc_html__( 'Tada', 'vidio' )                 => 'wpb_tada'
            ),
            'description' => esc_html__( 'Select type of animation if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.', 'vidio' ),
            'group'       => esc_html__( 'Haru Options', 'vidio' )
        );

        $add_duration_animation = array(
            'type'        => 'textfield',
            'heading'     => esc_html__( 'Animation Duration', 'vidio' ),
            'param_name'  => 'duration',
            'value'       => '',
            'description' => esc_html__( 'Duration in seconds. You can use decimal points in the value. Use this field to specify the amount of time the animation plays. <em>The default value depends on the animation, leave blank to use the default.</em>', 'vidio' ),
            'dependency'  => array(
                'element' => 'css_animation', 
                'value'   => array(
                    'wpb_fadeIn', 
                    'wpb_fadeInDown', 
                    'wpb_fadeInUp', 
                    'wpb_fadeInLeft', 
                    'wpb_fadeInRight', 
                    'wpb_bounceIn', 
                    'wpb_bounceInDown', 
                    'wpb_bounceInUp', 
                    'wpb_bounceInLeft', 
                    'wpb_bounceInRight', 
                    'wpb_zoomIn', 
                    'wpb_flipInX', 
                    'wpb_flipInY', 
                    'wpb_bounce', 
                    'wpb_flash', 
                    'wpb_shake', 
                    'wpb_pulse', 
                    'wpb_swing', 
                    'wpb_rubberBand',
                    'wpb_wobble', 
                    'wpb_tada'
                )
            ),
            'group'       => esc_html__( 'Haru Options', 'vidio' )
        );

        $add_delay_animation = array(
            'type'        => 'textfield',
            'heading'     => esc_html__( 'Animation Delay', 'vidio' ),
            'param_name'  => 'delay',
            'value'       => '',
            'description' => esc_html__( 'Delay in seconds. You can use decimal points in the value. Use this field to delay the animation for a few seconds, this is helpful if you want to chain different effects one after another above the fold.', 'vidio' ),
            'dependency'  => array(
                'element' => 'css_animation', 
                'value'   => array(
                    'wpb_fadeIn', 
                    'wpb_fadeInDown', 
                    'wpb_fadeInUp',
                    'wpb_fadeInLeft',
                    'wpb_fadeInRight', 
                    'wpb_bounceIn', 
                    'wpb_bounceInDown', 
                    'wpb_bounceInUp', 
                    'wpb_bounceInLeft', 
                    'wpb_bounceInRight', 
                    'wpb_zoomIn', 
                    'wpb_flipInX', 
                    'wpb_flipInY', 
                    'wpb_bounce', 
                    'wpb_flash', 
                    'wpb_shake', 
                    'wpb_pulse', 
                    'wpb_swing', 
                    'wpb_rubberBand', 
                    'wpb_wobble', 
                    'wpb_tada'
                )
            ),
            'group'       => esc_html__( 'Haru Options', 'vidio' )
        );

        $add_params_row = array(
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Row background overlay', 'vidio' ),
                'param_name'  => 'overlay_set',
                'description' => esc_html__( 'Hide or Show overlay on row background image.', 'vidio' ),
                'value'       => array(
                    esc_html__( 'Hide', 'vidio' )               => 'hide_overlay',
                    esc_html__( 'Show Overlay Color', 'vidio' ) => 'show_overlay_color',
                ),
                'group'       => esc_html__( 'Haru Options', 'vidio' )
            ),
            array(
                'type'        => 'colorpicker',
                'heading'     => esc_html__( 'Overlay color', 'vidio' ),
                'param_name'  => 'overlay_color',
                'description' => esc_html__( 'Select color for background overlay.', 'vidio' ),
                'value'       => '',
                'dependency'  => array(
                    'element' => 'overlay_set', 
                    'value'   => array('show_overlay_color')
                ),
                'group'       => esc_html__( 'Haru Options', 'vidio' )
            ),
            array(
                'type'        => 'number',
                'class'       => '',
                'heading'     => esc_html__( 'Overlay opacity', 'vidio' ),
                'param_name'  => 'overlay_opacity',
                'value'       => '50',
                'min'         => '1',
                'max'         => '100',
                'suffix'      => '%',
                'description' => esc_html__( 'Select opacity for overlay.', 'vidio' ),
                'dependency'  => array(
                    'element' => 'overlay_set', 
                    'value'   => array( 'show_overlay_color', 'show_overlay_image' )
                ),
                'group'       => esc_html__( 'Haru Options', 'vidio' )
            ),
            $add_css_animation,
            $add_duration_animation,
            $add_delay_animation,
        );

        $add_params_row_inner = array(
            $add_css_animation,
            $add_duration_animation,
            $add_delay_animation,
        );

        $add_params_column = array(
            $add_css_animation,
            $add_duration_animation,
            $add_delay_animation,
        );

        $add_params_heading = array(
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Heading Style', 'vidio' ),
                'param_name'  => 'heading_style',
                'description' => esc_html__( 'Choose Pre-made Heading style.', 'vidio' ),
                'value'       => array(
                    esc_html__( 'Default', 'vidio' )                                                           => 'default',
                    esc_html__( 'Heading Style 1 (Heading Primary Color - 32px)', 'vidio' )                    => 'heading_style_1',
                    esc_html__( 'Heading Style 2 (Primary Color - 16px)', 'vidio' )                            => 'heading_style_2',
                    esc_html__( 'Heading Style 3 (Heading Primary Color - 24px)', 'vidio' )                    => 'heading_style_3',
                    esc_html__( 'Heading Style 4 (Heading Primary Color - 18px)', 'vidio' )                    => 'heading_style_4',
                    esc_html__( 'Heading Style 5 (Heading Color - Upper Case - 14px)', 'vidio' )               => 'heading_style_5',
                    esc_html__( 'Heading Style 6 (Heading Color - 28px)', 'vidio' )                            => 'heading_style_6',
                    esc_html__( 'Footer Heading 1 (Primary Color - Underline - BG Dark)', 'vidio' )            => 'footer_style_1',
                    esc_html__( 'Footer Heading 2 (Primary Color - Underline - BG Light)', 'vidio' )           => 'footer_style_2',
                    esc_html__( 'Footer Heading 3 (Heading Color)', 'vidio' )                                  => 'footer_style_3',
                    esc_html__( 'Footer Heading 4 (White Color)', 'vidio' )                                    => 'footer_style_4',
                ),
                'weight' => 1, //  default 0 - unsorted and appended to bottom, 1 - appended to top
            ),
            array(
                'param_name'  => 'sub_heading',
                'type'        => 'textfield',
                'heading'     => esc_html__( 'Sub Title', 'vidio' ),
                'description' => esc_html__( 'Enter sub title.', 'vidio' ),
                'admin_label' => true,
                'dependency' => array(
                    'element' => 'heading_style',
                    'value'   => array( 'heading_style_7' ),
                ),
                'weight' => 1, //  default 0 - unsorted and appended to bottom, 1 - appended to top
            ),
        );

        $add_params_button = array(
            array(
                'type'        => 'dropdown',
                'heading'     => esc_html__( 'Button Style', 'vidio' ),
                'param_name'  => 'button_style',
                'description' => esc_html__( 'Choose Pre-made Button style.', 'vidio' ),
                'value'       => array(
                    esc_html__( 'Default', 'vidio' )                                        => 'default',
                    esc_html__( 'Button Style 1 (Background Primary Color)', 'vidio' )      => 'button_style_1',
                ),
                'weight' => 1, //  default 0 - unsorted and appended to bottom, 1 - appended to top
            ),
        );

        // 1. Add new parameters for row
        foreach( $add_params_row as $param_row ) {
            vc_add_param( 'vc_row', $param_row );
        }
        // 2. Add new parameters for row_inner
        foreach( $add_params_row_inner as $param_row_inner ) {
            vc_add_param( 'vc_row_inner', $param_row_inner );
        }

        // 3. Add new parameters for column
        foreach( $add_params_column as $param_column ) {
            vc_add_param( 'vc_column', $param_column );
        }
        
        // 4. Add new parameters for custom heading
        foreach( $add_params_heading as $param_heading ) {
            vc_add_param( 'vc_custom_heading', $param_heading );
        }

        // 5. Add new parameters for button
        foreach( $add_params_button as $param_button ) {
            vc_add_param( 'vc_btn', $param_button );
        }
    }
}

haru_add_vc_param();